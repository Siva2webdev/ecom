import React from 'react';

const Footer = () => {
  return (
    <footer>
      <h3>&copy; Bindaas E-Commerce Store</h3>
    </footer>
  );
};

export default Footer;
